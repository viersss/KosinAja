-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_kosinaja
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kos`
--

DROP TABLE IF EXISTS `kos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kos` (
  `id_kos` int(11) NOT NULL AUTO_INCREMENT,
  `id_pemilik` int(11) NOT NULL,
  `nama_kos` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `harga_per_bulan` int(11) NOT NULL,
  `fasilitas` text DEFAULT NULL,
  `jenis_kos` enum('Putra','Putri','Campur') NOT NULL,
  `gambar` mediumblob DEFAULT NULL,
  `kontak_pemilik` varchar(20) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_kos`),
  KEY `id_pemilik` (`id_pemilik`),
  CONSTRAINT `kos_ibfk_1` FOREIGN KEY (`id_pemilik`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kos`
--

LOCK TABLES `kos` WRITE;
/*!40000 ALTER TABLE `kos` DISABLE KEYS */;
INSERT INTO `kos` VALUES (36,1,'Griya Cempaka','Jl. Cipinang Cempedak I No.20, RT.4/RW.6, Cipinang Cempedak, Kecamatan Jatinegara, Kota Jakarta Timur',1200000,'AC, Wi-Fi, Kasur, Meja Belajar, Akses 24 Jam','Putra',_binary 'default.jpg','081122334455',NULL),(45,1,'Kos Melati STIS','Jl. Otto Iskandardinata No.64C, RT.1/RW.4, Bidara Cina, Kecamatan Jatinegara, Kota Jakarta Timur',850000,'AC, Kamar Mandi Dalam, Wi-Fi, Kasur, Lemari','Putri',_binary 'default.jpg','081234567890',NULL),(47,7,'Kos Pelangi','Jl. Gelatik No.5, RT.2/RW.3, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',900000,'AC, Wi-Fi, Lemari, Meja Belajar','Putri',NULL,'081234567802',NULL),(48,7,'Kos Zamrud','Jl. Otto Iskandardinata No.45, RT.3/RW.5, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',1200000,'AC, Kamar Mandi Dalam, TV, Kulkas Mini','Putri',NULL,'081234567803',NULL),(49,7,'Kos Bunga Bangkai','Jl. Inspeksi Kalimalang No.3, RT.4/RW.7, Cipinang Melayu, Kec. Makasar, Jakarta Timur 13620',950000,'AC, Springbed, Meja Belajar, Lemari','Putri',NULL,'081234567804',NULL),(50,7,'Kos Mawar','Jl. Otto Iskandardinata No.32, RT.1/RW.2, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',850000,'AC, Kamar Mandi Dalam, Wi-Fi','Putri',NULL,'081234567805',NULL),(51,7,'Kos Delima','Jl. Otista Raya Gang V No.7, RT.5/RW.1, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',900000,'AC, Kamar Mandi Dalam, Lemari','Putri',NULL,'081234567806',NULL),(52,7,'Kos Anggrek','Jl. Otto Iskandardinata No.56, RT.2/RW.6, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',1200000,'AC, Kamar Mandi Dalam, TV, Kulkas Mini','Putri',NULL,'081234567807',NULL),(53,7,'Kos Pelangi Indah','Jl. Gelatik No.8, RT.3/RW.4, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',880000,'AC, Kamar Mandi Dalam, Meja Belajar','Putri',NULL,'081234567808',NULL),(54,7,'Kos Mutiara STIS','Jl. Otto Iskandardinata Gang III No.5, RT.4/RW.3, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',1100000,'AC, Water Heater, Wi-Fi, Dapur Kecil','Putri',NULL,'081234567809',NULL),(55,7,'Kos Berlian','Jl. Kebon Nanas Utara III No.9, RT.7/RW.5, Cipinang Besar, Kec. Jatinegara, Jakarta Timur 13410',1150000,'AC, Kamar Mandi Dalam, Water Heater, Wi-Fi','Putri',NULL,'081234567811',NULL),(56,7,'Wisma Mahasiswa STIS','Jl. Otista Raya Gang IV No.12, RT.2/RW.1, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',950000,'AC, Kamar Mandi Dalam, Wi-Fi, Dapur Bersama','Putra',NULL,'081234567812',NULL),(57,7,'Kos Barokah 21','Jl. Kebon Nanas Utara II No.15, RT.10/RW.5, Cipinang Besar Sel., Kec. Jatinegara, Jakarta Timur 13410',780000,'Kipas Angin, Kamar Mandi Luar, Lemari','Putra',NULL,'081234567813',NULL),(58,7,'Kos Putra Jaya','Jl. Cipinang Cempedak I No.10, RT.4/RW.6, Cipinang Cempedak, Kec. Jatinegara, Jakarta Timur 13340',800000,'Kipas Angin, Kamar Mandi Luar, Lemari','Putra',NULL,'081234567814',NULL),(59,7,'Kos Sejahtera','Jl. Cipinang Muara I No.30, RT.5/RW.3, Cipinang Muara, Kec. Jatinegara, Jakarta Timur 13420',800000,'Kipas Angin, Lemari, Parkir Motor','Putra',NULL,'081234567815',NULL),(60,7,'Kos Jaya Abadi','Jl. Kebon Nanas Utara I No.14, RT.8/RW.4, Cipinang Besar, Kec. Jatinegara, Jakarta Timur 13410',820000,'Kipas Angin, Kamar Mandi Luar, Lemari','Putra',NULL,'081234567817',NULL),(61,7,'Kos Nurul Hidayah','Jl. Cipinang Cempedak II No.11, RT.9/RW.8, Cipinang Cempedak, Kec. Jatinegara, Jakarta Timur 13340',790000,'AC, Wi-Fi, Meja Belajar, Akses 24 Jam','Putra',NULL,'081234567818',NULL),(62,7,'Kos Harmoni Indah','Jl. Otista III No.15, RT.3/RW.2, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',950000,'AC, Wi-Fi, Kamar Mandi Dalam, Lemari, Meja Belajar','Campur',NULL,'081234560001',NULL),(63,7,'Kos BonaSel Residence','Jl. Kebon Nanas Selatan No.22, RT.5/RW.6, Cipinang Besar Selatan, Kec. Jatinegara, Jakarta Timur 13410',850000,'Kipas Angin, Wi-Fi, Kamar Mandi Luar, Lemari','Campur',NULL,'081234560002',NULL),(64,7,'Kos Mitra Asri','Jl. Kebon Nanas Utara No.9, RT.4/RW.3, Cipinang Besar Utara, Kec. Jatinegara, Jakarta Timur 13410',1100000,'AC, Kamar Mandi Dalam, Water Heater, Wi-Fi','Campur',NULL,'081234560003',NULL),(65,7,'Kos Pelita Bersama','Jl. Otista IV No.7, RT.2/RW.1, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',900000,'AC, Wi-Fi, Meja Belajar, Lemari','Campur',NULL,'081234560004',NULL),(66,7,'Kos Cendana Campur','Jl. Cipinang Besar Selatan III No.11, RT.6/RW.5, Cipinang Besar Selatan, Kec. Jatinegara, Jakarta Timur 13410',880000,'Kipas Angin, Kamar Mandi Luar, Lemari, Parkir Motor','Campur',NULL,'081234560005',NULL),(67,7,'Kos Damai Sentosa','Jl. Otista Raya Gang VI No.18, RT.7/RW.2, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',1200000,'AC, Kamar Mandi Dalam, TV, Kulkas Mini','Campur',NULL,'081234560006',NULL),(68,7,'Kos Sejahtera 88','Jl. Cipinang Cempedak III No.12, RT.5/RW.6, Cipinang Cempedak, Kec. Jatinegara, Jakarta Timur 13340',1050000,'AC, Kamar Mandi Dalam, Wi-Fi, Meja Belajar','Campur',NULL,'081234560008',NULL),(69,7,'Kos BonaSut Asri','Jl. Kebon Nanas Utara III No.20, RT.9/RW.7, Cipinang Besar Utara, Kec. Jatinegara, Jakarta Timur 13410',950000,'AC, Wi-Fi, Lemari, Meja Belajar','Putra',NULL,'081234560009',NULL),(70,7,'Kos Persada Berseri','Jl. Otista Raya Gang V No.14, RT.4/RW.3, Bidara Cina, Kec. Jatinegara, Jakarta Timur 13330',1150000,'AC, Kamar Mandi Dalam, Water Heater, Wi-Fi','Campur',NULL,'081234560010',NULL);
/*!40000 ALTER TABLE `kos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  9:12:46
