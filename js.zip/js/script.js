/**
 * File script.js untuk KosinAja
 * -------------------------------------
 * Fungsionalitas:
 * 1. Hero Slideshow
 * 2. Live Search Suggestion
 * 3. Animasi Fade-in on Scroll
 * 4. Galeri Foto di Halaman Detail
 * 5. Mobile Navigation (Hamburger Menu)
 */

document.addEventListener('DOMContentLoaded', function() {

    // ======================================================
    // BAGIAN 1: HERO SLIDESHOW
    // ======================================================
    const slides = document.querySelectorAll('.hero-slide');
    if (slides.length > 0) {
        let currentSlide = 0;
        slides[currentSlide].classList.add('active'); // Tampilkan slide pertama

        setInterval(() => {
            slides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + 1) % slides.length;
            slides[currentSlide].classList.add('active');
        }, 5000); // Ganti gambar setiap 5 detik
    }

    // ======================================================
    // BAGIAN 2: FUNGSI LIVE-SEARCH (SUGGESTION)
    // ======================================================
    function setupLiveSearch(inputId, suggestionsId, fieldName) {
        const inputElement = document.getElementById(inputId);
        const suggestionsElement = document.getElementById(suggestionsId);

        if (!inputElement) return;

        inputElement.addEventListener('keyup', function() {
            const keyword = this.value;
            if (keyword.length > 0) {
                fetch(`php/live_search.php?keyword=${encodeURIComponent(keyword)}&field=${fieldName}`)
                    .then(response => response.text())
                    .then(data => {
                        suggestionsElement.innerHTML = data;
                        suggestionsElement.style.display = 'block';
                    });
            } else {
                suggestionsElement.style.display = 'none';
            }
        });

        suggestionsElement.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('suggestion-item')) {
                inputElement.value = e.target.textContent;
                suggestionsElement.style.display = 'none';
            }
        });
    }

    setupLiveSearch('nama_kos', 'nama_kos_suggestions', 'nama_kos');
    setupLiveSearch('alamat', 'alamat_suggestions', 'alamat');

    document.addEventListener('click', function(e) {
        document.querySelectorAll('.suggestion-box').forEach(box => {
            const input = box.previousElementSibling;
            if (input && !input.contains(e.target) && !box.contains(e.target)) {
                box.style.display = 'none';
            }
        });
    });

    // ======================================================
    // BAGIAN 3: EFEK ANIMASI SAAT SCROLLING
    // ======================================================
    const scrollObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                scrollObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    const elementsToAnimate = document.querySelectorAll('.feature-card, .kos-listing-card, .info-card, .step-item, .about-container');
    elementsToAnimate.forEach((element, index) => {
        element.style.setProperty('--delay', `${index * 100}ms`);
        element.classList.add('fade-in-section');
        scrollObserver.observe(element);
    });

    // ======================================================
    // BAGIAN 4: GALERI FOTO DI HALAMAN DETAIL
    // ======================================================
    const mainImage = document.getElementById('main-image');
    const thumbnailsContainer = document.querySelector('.gallery-thumbnails');

    if (mainImage && thumbnailsContainer) {
        thumbnailsContainer.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('thumbnail-image')) {
                mainImage.src = e.target.src;
            }
        });
    }

    // ======================================================
    // BAGIAN 5: MOBILE NAVIGATION (HAMBURGER MENU)
    // ======================================================
    const hamburger = document.querySelector('.hamburger-menu');
    const mobileNavOverlay = document.querySelector('.mobile-nav-overlay');
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-overlay a');

    if (hamburger && mobileNavOverlay) {
        hamburger.addEventListener('click', () => {
            mobileNavOverlay.classList.toggle('active');
            // Toggle a class on body to prevent scrolling when menu is open
            document.body.classList.toggle('no-scroll');
        });

        // Close menu when a link is clicked
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileNavOverlay.classList.remove('active');
                document.body.classList.remove('no-scroll');
            });
        });
    }
});
