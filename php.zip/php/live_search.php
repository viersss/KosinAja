<?php
require 'connect.php'; 

$output = '';
if (isset($_GET['keyword']) && isset($_GET['field'])) {
    $keyword = trim($_GET['keyword']);
    $field = $_GET['field'];

    if (($field === 'nama_kos' || $field === 'alamat') && !empty($keyword)) {
        $search_term = '%' . $keyword . '%';
        
        $stmt = $pdo->prepare("SELECT DISTINCT $field FROM kos WHERE $field LIKE ? LIMIT 5");
        $stmt->execute([$search_term]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($results) {
            foreach ($results as $result) {
                $output .= '<div class="suggestion-item">' . htmlspecialchars($result[$field]) . '</div>';
            }
        } else {
            $output = '<div class="suggestion-item no-result">Tidak ada saran</div>';
        }
    }
}
echo $output;
?>