<?php
session_start();
require 'connect.php';

// Keamanan: Pastikan user login dan request adalah POST
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php");
    exit();
}

$id_user = $_SESSION['user_id'];

// --- LOGIKA UNTUK UBAH EMAIL ---
if (isset($_POST['change_email'])) {
    $new_email = trim($_POST['new_email']);

    // Validasi email
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../profile.php?status=email_invalid");
        exit();
    }

    try {
        $stmt = $pdo->prepare("UPDATE users SET email = ? WHERE id = ?");
        $stmt->execute([$new_email, $id_user]);
        header("Location: ../profile.php?status=email_success");
        exit();
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Error duplikasi email
            header("Location: ../profile.php?status=email_duplicate");
            exit();
        }
        header("Location: ../profile.php?status=dberror");
        exit();
    }
}


// --- LOGIKA UNTUK UBAH PASSWORD ---
if (isset($_POST['change_password'])) {
    $password_lama = $_POST['password_lama'];
    $password_baru = $_POST['password_baru'];
    $konfirmasi_password = $_POST['konfirmasi_password_baru'];

    // 1. Ambil hash password saat ini dari DB
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$id_user]);
    $user = $stmt->fetch();

    // 2. Verifikasi password lama
    if (!$user || !password_verify($password_lama, $user['password'])) {
        header("Location: ../profile.php?status=pwd_wrong");
        exit();
    }

    // 3. Cek apakah password baru valid
    $password_pattern = "/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/";
    if (!preg_match($password_pattern, $password_baru)) {
        header("Location: ../profile.php?status=pwd_invalid");
        exit();
    }

    // 4. Cek apakah password baru dan konfirmasinya cocok
    if ($password_baru !== $konfirmasi_password) {
        header("Location: ../profile.php?status=pwd_mismatch");
        exit();
    }

    // 5. Jika semua valid, hash dan update password baru
    $new_hashed_password = password_hash($password_baru, PASSWORD_DEFAULT);
    $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    if($update_stmt->execute([$new_hashed_password, $id_user])) {
        header("Location: ../profile.php?status=pwd_success");
        exit();
    } else {
        header("Location: ../profile.php?status=dberror");
        exit();
    }
}

// Jika tidak ada aksi yang cocok, kembalikan ke profil
header("Location: ../profile.php");
exit();

?>