<?php
session_start();
require 'connect.php';

// Keamanan: pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto_profil'])) {
    $id_user = $_SESSION['user_id'];
    
    $file = $_FILES['foto_profil'];
    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileError = $file['error'];
    
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($fileExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 2000000) { // Batas 2MB
                // Buat nama file unik untuk mencegah penimpaan file
                $newFileName = "profile_" . $id_user . "." . $fileExt;
                $fileDestination = '../media/profiles/' . $newFileName;
                
                // Pindahkan file yang di-upload ke folder tujuan
                if (move_uploaded_file($fileTmpName, $fileDestination)) {
                    // Update nama file di database
                    $stmt = $pdo->prepare("UPDATE users SET foto_profil = ? WHERE id = ?");
                    if ($stmt->execute([$newFileName, $id_user])) {
                        header("Location: ../profile.php?status=upload_success");
                        exit();
                    }
                }
            } else {
                header("Location: ../profile.php?status=file_too_large");
                exit();
            }
        } else {
            header("Location: ../profile.php?status=upload_error");
            exit();
        }
    } else {
        header("Location: ../profile.php?status=invalid_type");
        exit();
    }
}
header("Location: ../profile.php");
exit();
?>