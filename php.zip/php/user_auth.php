<?php
// Memulai session di baris paling atas adalah praktik terbaik.
session_start();

// Memuat file koneksi database.
require 'connect.php';

// Memastikan request adalah metode POST untuk keamanan.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // LOGIKA REGISTRASI DENGAN VALIDASI PASSWORD
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password']; // Ambil password asli dulu untuk divalidasi
    $role = $_POST['role'];

    // --- BLOK VALIDASI PASSWORD BARU ---
    // Pola regex: minimal 8 karakter, harus ada huruf dan angka
    $password_pattern = "/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/";
    
    if (!preg_match($password_pattern, $password)) {
        // Jika password tidak sesuai pola, kembalikan ke form register dengan status error
        header("Location: ../register.php?status=pwd_invalid");
        exit();
    }
    // --- AKHIR BLOK VALIDASI ---

    // Jika validasi lolos, baru hash passwordnya
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        // Simpan password yang sudah di-hash
        $stmt->execute([$username, $email, $hashed_password, $role]);
        
        header("Location: ../login.php?status=reg_success");
        exit();

    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            header("Location: ../register.php?status=duplicate");
            exit();
        } else {
            header("Location: ../register.php?status=dberror");
            exit();
        }
    }
}


    // --- LOGIKA LOGIN ---
    if (isset($_POST['login'])) {
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        // Query diubah untuk mencari berdasarkan username
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifikasi user ada dan password cocok
        if ($user && password_verify($password, $user['password'])) {
            // Set session jika berhasil
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Alihkan berdasarkan peran (role)
            if ($user['role'] === 'owner') {
                header("Location: ../dashboard.php");
            } else {
                header("Location: ../index.php");
            }
            exit();
            
        } else {
            // Jika username atau password salah
            header("Location: ../login.php?status=login_failed");
            exit();
        }
    }
}

// Jika ada yang mencoba mengakses file ini secara langsung, alihkan ke halaman utama.
header("Location: ../index.php");
exit();
?>